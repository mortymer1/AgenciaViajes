import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ClienteService } from '../services/cliente.service'; // El servicio que vamos a crear

@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: ['./registro.component.css']
})
export class RegistroComponent {
  registroForm: FormGroup;

  constructor(private fb: FormBuilder, private clienteService: ClienteService) {
    // Definir los controles del formulario
    this.registroForm = this.fb.group({
      usuario: ['', Validators.required],
      password: ['', Validators.required],
      direccion: ['', Validators.required],
      dni: ['', Validators.required],
      tarjeta: ['', Validators.required]
    });
  }

  // Método para enviar el formulario
  onSubmit() {
    if (this.registroForm.valid) {
      this.clienteService.altaCliente(this.registroForm.value).subscribe(response => {
        console.log('Cliente registrado correctamente', response);
      }, error => {
        console.log('Error al registrar cliente', error);
      });
    }
  }
}
