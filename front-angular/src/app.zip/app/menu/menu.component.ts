import { Component, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent {
  @Output() seccionSeleccionada = new EventEmitter<string>();

  seleccionarSeccion(seccion: string) {
    this.seccionSeleccionada.emit(seccion);
  }
}
