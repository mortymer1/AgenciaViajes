import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccesoComponent } from './acceso/acceso.component';
import { ReservarComponent } from './reservar/reservar.component';
import { MisReservasComponent } from './mis-reservas/mis-reservas.component';
import { InicioComponent } from './inicio/inicio.component'; // Nuevo componente
import { RegistroComponent } from './registro/registro.component';

const routes: Routes = [
  { path: 'acceso', component: AccesoComponent },
  { path: 'reservar', component: ReservarComponent },
  { path: 'mis-reservas', component: MisReservasComponent },
  { path: 'registro', component: RegistroComponent },
  { path: '', component: InicioComponent, pathMatch: 'full' }, // Ruta por defecto
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
