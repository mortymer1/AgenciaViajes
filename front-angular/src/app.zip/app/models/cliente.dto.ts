export interface ClienteDto {
    usuario: string;
    password: string;
    direccion: string;
    tarjeta: string;
    dni: string;
  }
  