export interface Vuelo {
    idvuelo: number;
    company: string;
    fecha: string;
    precio: number;
    plazas: number;
    destino: string;
  }
  