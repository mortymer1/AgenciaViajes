export interface Hotel {
    idHotel: number;
    nombre: string;
    precio: number;
    categoria: number;
    disponible: number;
    localizacion: string;
  }
  